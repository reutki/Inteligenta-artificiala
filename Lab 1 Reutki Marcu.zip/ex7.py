import numpy
x = numpy.random.uniform(0,5,250)
print(x)