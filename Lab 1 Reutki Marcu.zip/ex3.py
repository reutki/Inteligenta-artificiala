import numpy
speed = [86,87,88,86,87,85,86]
x = numpy.std(speed)
print(x)